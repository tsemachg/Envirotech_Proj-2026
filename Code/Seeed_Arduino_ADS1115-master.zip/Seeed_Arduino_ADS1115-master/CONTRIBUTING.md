## Contributing guidelines

All guidelines for contributing to the Seeed_Arduino_ADS1115 repository can be found at [`How to contribute guideline`](https://github.com/Seeed-Studio/Seeed_Arduino_ADS1115/wiki/How_to_contribute).
